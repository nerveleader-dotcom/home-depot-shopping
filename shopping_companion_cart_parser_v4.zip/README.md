Shopping Companion v0.3.1: cart parser v4.
Changes: cart-scoped candidate discovery, visible quantity controls, product title extraction, expected cart count cross-check, more detailed privacy-safe diagnostics, Java 17 source compatibility.
Note: new parser requires testing against a signed-in Home Depot cart. Failed or incomplete extraction leaves saved list unchanged.
