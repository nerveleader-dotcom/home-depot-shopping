package com.shoppingcompanion.homedepot;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;
import android.view.WindowInsets;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView appView, cartView;
    private LinearLayout cartPanel;
    private FrameLayout root;
    private boolean importing = false;
    private boolean inspecting = false;
    private boolean attemptedOnThisPage = false;
    private int attempts=0;
    private int importGeneration=0;
    private String diagnostics="No diagnostic result yet";
    private TextView progress;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        setContentView(root);
        appView = makeView();
        root.addView(appView);
        appView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void openCart() { runOnUiThread(() -> openCartBrowser()); }
        }, "ShoppingBridge");
        appView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url.startsWith("file:///android_asset/")) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }
        });
        appView.loadUrl("file:///android_asset/index.html");
        CookieManager.getInstance().setAcceptCookie(true);
    }
    private WebView makeView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setJavaScriptCanOpenWindowsAutomatically(false);
        w.setWebChromeClient(new WebChromeClient());
        return w;
    }
    private void openCartBrowser() {
        if (cartView != null) return;
        importing = true;
        cartView = makeView();
        CookieManager.getInstance().setAcceptThirdPartyCookies(cartView, true);
        LinearLayout browserPanel = new LinearLayout(this);
        browserPanel.setOrientation(LinearLayout.VERTICAL);
        browserPanel.setBackgroundColor(0xFF182332);
        Button back = new Button(this); back.setText("Close Home Depot");
        Button importButton = new Button(this); importButton.setText("Import Cart Now");
        LinearLayout controls = new LinearLayout(this);
        controls.addView(back, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(importButton, new LinearLayout.LayoutParams(0, -2, 1));
        browserPanel.addView(controls);
        progress = new TextView(this);
        progress.setTextColor(0xFFFFFFFF);
        progress.setPadding(20, 8, 20, 8);
        progress.setVisibility(View.GONE);
        browserPanel.addView(progress);
        browserPanel.addView(cartView, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(browserPanel);
        browserPanel.setOnApplyWindowInsetsListener((view, insets) -> { view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom()); return insets; });
        browserPanel.requestApplyInsets();
        cartPanel = browserPanel;
        back.setOnClickListener(v -> closeCart());
        importButton.setOnClickListener(v -> startInspection());
        cartView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                Uri u = Uri.parse(url);
                String host = u.getHost();
                if (host == null || !(host.equals("homedepot.com") || host.endsWith(".homedepot.com"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch(Exception ignored) {}
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView v, String url) {
                attemptedOnThisPage = false;
                if (importing && (url.contains("/mycart") || url.contains("/cart"))) {
                    v.postDelayed(() -> { if (importing && attempts==0) startInspection(); }, 2000);
                }
            }
        });
        cartView.loadUrl("https://www.homedepot.com/mycart/home");
        Toast.makeText(this, "Sign in if needed. Cart import will be attempted automatically.", Toast.LENGTH_LONG).show();
    }
    private void startInspection() {
        if (cartView == null) return;
        importing=true;
        inspecting=false;
        attempts=0;
        int generation=++importGeneration;
        if(progress!=null){progress.setText("Reading Home Depot cart... 0/15 seconds");progress.setVisibility(View.VISIBLE);}
        inspectAttempt(generation);
    }
    private void inspectAttempt(int generation) {
        if(cartView==null || generation!=importGeneration || !importing || inspecting) return;
        inspecting=true;
        // Only rendered cart data. Never capture page HTML, form fields, account data, or cookies.
        String script = """
          (function(){try{
            const body=document.body;
            if(!body)return JSON.stringify({items:[],empty:false,rows:0,links:0,expected:-1,qualified:0,reason:'no-body'});
            const norm=s=>String(s||'').replace(/\\s+/g,' ').trim();
            const visible=e=>{if(!e)return false;let s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden';};
            const bodyText=body.innerText||'';
            const heading=[...document.querySelectorAll('h1,h2,h3,[role=heading]')].find(e=>/^cart\\s*\\(\\s*\\d+\\s*\\)$/i.test(norm(e.innerText)));
            const countMatch=heading?norm(heading.innerText).match(/\\((\\d+)\\)/):null;
            const expected=countMatch?Number(countMatch[1]):-1;
            const allLinks=[...document.querySelectorAll('a[href*="/p/"]')];
            const isProductLink=a=>a&&a.matches('a[href*="/p/"]')&&!a.closest('header,nav,footer');
            const hasStepper=e=>{
              if(!e)return false;
              if(e.querySelector('input[type=number],select,[data-testid*=quantity],[aria-label*=Quantity],[aria-label*=quantity]'))return true;
              const buttons=[...e.querySelectorAll('button,[role=button]')];
              return buttons.some(b=>/^(\\+|add one|increase|increment)$/i.test(norm(b.innerText))||/increase|increment|add quantity/i.test(b.getAttribute('aria-label')||''))&&
                buttons.some(b=>/^(−|-|decrease|decrement)$/i.test(norm(b.innerText))||/decrease|decrement|remove quantity/i.test(b.getAttribute('aria-label')||''));
            };
            const hasCartContext=e=>{
              const t=norm(e.innerText);
              return hasStepper(e)||/limit\\s+\\d+\\s+per\\s+order/i.test(t)||/quantity\\s*:/i.test(t);
            };
            const isContainer=e=>e&&e!==body&&norm(e.innerText).length<1800&&e.querySelectorAll('a[href*="/p/"]').length<=8;
            const links=allLinks.filter(isProductLink);
            const candidateRows=[];
            for(const a of links){
              let e=a.parentElement;
              for(let i=0;e&&e!==body&&i<10;i++,e=e.parentElement){
                if(isContainer(e)&&hasCartContext(e)){
                  // Prefer the smallest card that contains both the link and quantity controls.
                  candidateRows.push(e);break;
                }
              }
            }
            // Also inspect cart-specific selectors, which can contain nested wrappers.
            const selectors=['[data-testid*="cart-item"]','[data-testid*="CartItem"]','[class*="cartItem"]','[class*="CartItem"]','[data-automation-id*="cart-item"]','[data-testid*="line-item"]'];
            const structured=[...new Set(selectors.flatMap(sel=>[...document.querySelectorAll(sel)]))];
            for(const r of structured){
              if(isContainer(r)&&hasCartContext(r)&&(r.querySelector('a[href*="/p/"]')||r.querySelector('img[alt]')))candidateRows.push(r);
            }
            const rows=[...new Set(candidateRows)].filter(visible);
            const parseMoney=s=>{let m=String(s||'').match(/\\$\\s*([\\d,]+(?:\\.\\d{2})?)/);return m?Number(m[1].replace(/,/g,'')):null;};
            const nameFor=(r,a)=>{
              const probes=[
                ...r.querySelectorAll('[data-testid*="product-title"],[data-testid*="product-name"],[class*="productTitle"],h1,h2,h3,[itemprop="name"]'),
                a,...r.querySelectorAll('img[alt]')
              ];
              for(const x of probes){
                const t=norm(x.tagName==='IMG'?x.alt:(x.innerText||x.getAttribute('aria-label')||x.getAttribute('title')));
                if(t.length>=13&&!/^(cart|home depot|view details|shop now|product details)/i.test(t))return t.slice(0,240);
              }
              // Conservative fallback: a long line that resembles a product title.
              const lines=(r.innerText||'').split('\\n').map(norm).filter(Boolean);
              return (lines.find(t=>t.length>=24&&!/^(cart|shipping|pickup|free|limit|attachment|battery|checkout|protection|quantity|save|delivery|remove|compare|subtotal)/i.test(t)&&!t.includes('$'))||'').slice(0,240);
            };
            const quantityFor=r=>{
              const c=r.querySelector('input[type=number],select,[data-testid*="quantity"],[aria-label*="Quantity"],[aria-label*="quantity"]');
              if(c){
                const raw=c.value||c.getAttribute('aria-label')||c.innerText||'';
                const m=String(raw).match(/\\b(\\d+)\\b/);
                if(m&&Number(m[1])>0)return Number(m[1]);
              }
              const buttons=[...r.querySelectorAll('button,[role=button]')];
              const plus=buttons.find(b=>/^(\\+|increase)$/i.test(norm(b.innerText))||/increase|increment/i.test(b.getAttribute('aria-label')||''));
              if(plus){
                let p=plus.parentElement;
                for(let depth=0;p&&depth<3;depth++,p=p.parentElement){
                  const parts=(p.innerText||'').split('\\n').map(norm).filter(Boolean);
                  const numbers=parts.filter(t=>/^\\d{1,3}$/.test(t)).map(Number);
                  if(numbers.length===1&&numbers[0]>0)return numbers[0];
                }
              }
              // Never guess the quantity when it cannot be verified.
              return null;
            };
            const pricesFor=r=>{
              const nodes=[...r.querySelectorAll('[data-testid*="price"],[class*="price"],[data-automation-id*="price"],[itemprop="price"]')];
              for(const n of nodes){
                if(!visible(n))continue;
                const amt=parseMoney(n.innerText||n.getAttribute('content'));
                if(amt!==null&&Number.isFinite(amt))return amt;
              }
              const lines=(r.innerText||'').split('\\n').map(norm).filter(x=>x.includes('$')&&!/total|subtotal|savings|shipping|delivery/i.test(x));
              return lines.length?parseMoney(lines[0]):null;
            };
            const parsed=rows.map(r=>{
              const a=[...r.querySelectorAll('a[href*="/p/"]')].find(isProductLink);
              const name=nameFor(r,a);
              const quantity=quantityFor(r);
              const price=pricesFor(r);
              return {name,quantity,price,url:a?.href||'',row:r};
            });
            const valid=parsed.filter(x=>x.name&&Number.isSafeInteger(x.quantity)&&x.quantity>0);
            const dedup=new Map();
            for(const x of valid){
              const key=x.url.split('?')[0].replace(/\\/$/,'')||x.name.toLowerCase();
              if(!dedup.has(key)||x.name.length>dedup.get(key).name.length)dedup.set(key,x);
            }
            const items=[...dedup.values()].map(({name,quantity,price,url})=>({name,quantity,price,url}));
            const empty=/your cart is empty|shopping cart is empty|no items in your cart/i.test(bodyText);
            return JSON.stringify({items,empty,rows:structured.length,links:allLinks.length,expected,
              candidates:rows.length,withName:parsed.filter(x=>x.name).length,
              withQuantity:parsed.filter(x=>Number.isSafeInteger(x.quantity)).length,
              withPrice:parsed.filter(x=>x.price!==null).length,qualified:valid.length,
              reason:'cart-product-and-stepper-scan'});
          }catch(e){return JSON.stringify({items:[],empty:false,rows:0,links:0,expected:-1,candidates:0,reason:'script-error:'+String(e&&e.name||'unknown')});}})()
          """;
        cartView.evaluateJavascript(script, result -> {
            if(generation!=importGeneration || cartView==null)return;
            inspecting=false;
            try {
                String decoded=new JSONArray("["+result+"]").getString(0);
                JSONObject obj=new JSONObject(decoded);
                JSONArray items=obj.optJSONArray("items");
                int found=items==null?0:items.length();
                int expected=obj.optInt("expected",-1);
                int sumQuantity=0;
                if(items!=null){for(int i=0;i<items.length();i++)sumQuantity+=items.optJSONObject(i).optInt("quantity",0);}
                diagnostics="Attempt: "+(attempts+1)+" of 15"
                  +"\nCart item count shown: "+expected
                  +"\nCart selectors detected: "+obj.optInt("rows")
                  +"\nPage product links: "+obj.optInt("links")
                  +"\nPossible item cards: "+obj.optInt("candidates")
                  +"\nCards with name: "+obj.optInt("withName")
                  +"\nCards with quantity: "+obj.optInt("withQuantity")
                  +"\nCards with price: "+obj.optInt("withPrice")
                  +"\nValid unique products: "+found
                  +"\nTotal product quantity: "+sumQuantity
                  +"\nEmpty cart marker: "+obj.optBoolean("empty")
                  +"\nExtraction state: "+obj.optString("reason");
                if(obj.optBoolean("empty")){finishInspection();showError("Your Home Depot cart is empty. Your shopping list was not changed.");return;}
                // Never replace a list based on an incomplete extraction.
                // Only proceed if qualified unique products account for the cart's displayed count.
                // Home Depot may display the number of line items or the summed quantity.
                if(found>0 && expected>0 && (found==expected || sumQuantity==expected)){
                    finishInspection();
                    new AlertDialog.Builder(this).setTitle("Replace shopping list?")
                      .setMessage("Replace your current shopping list with "+found+" Home Depot cart items?")
                      .setNegativeButton("Cancel",(d,w)->closeCart())
                      .setPositiveButton("Replace",(d,w)->{
                          closeCart();
                          appView.evaluateJavascript("window.importHomeDepotCart("+JSONObject.quote(items.toString())+")",null);
                      }).show();return;
                }
            }catch(Exception e){diagnostics="Extraction response could not be parsed. Attempt: "+(attempts+1)+" of 15";}
            attempts++;
            if(attempts>=15){finishInspection();showRetryDialog("Could not reliably read all Home Depot cart items within 15 seconds. Your shopping list is unchanged.");return;}
            if(progress!=null)progress.setText("Reading Home Depot cart... "+attempts+"/15 seconds");
            cartView.postDelayed(()->inspectAttempt(generation),1000);
        });
    }
    private void finishInspection(){importing=false;if(progress!=null)progress.setVisibility(View.GONE);}
    private void showRetryDialog(String message) {
        if(cartView==null)return;
        new AlertDialog.Builder(this).setTitle("Cart import not completed").setMessage(message)
          .setPositiveButton("Retry",(d,w)->startInspection())
          .setNeutralButton("Copy Diagnostics",(d,w)->{
              ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
              cm.setPrimaryClip(ClipData.newPlainText("Cart diagnostics",diagnostics));
              Toast.makeText(this,"Diagnostics copied",Toast.LENGTH_SHORT).show();
          })
          .setNegativeButton("Cancel",(d,w)->closeCart()).show();
    }
    private void showError(String message) { new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",(d,w)->{}).show(); }
    private void closeCart() { importGeneration++; importing=false; inspecting=false; if(cartView!=null){ if(cartPanel!=null)root.removeView(cartPanel);cartView.destroy();cartView=null;cartPanel=null;} }
    @Override public void onBackPressed() {
        if (cartView!=null) { if(cartView.canGoBack())cartView.goBack(); else closeCart(); }
        else if (appView.canGoBack()) appView.goBack(); else super.onBackPressed();
    }
}
