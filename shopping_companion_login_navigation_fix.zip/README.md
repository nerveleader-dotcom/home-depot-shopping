# Home Depot Shopping Companion (prototype Android APK)

This is an Android WebView wrapper around the existing local HTML prototype. It is NOT a completed native app. It does not connect to Home Depot's authenticated cart or provide live barcode scanning/price comparison.

## Build

Upload the CONTENTS of this ZIP to the root of your GitHub repository, preserving folders including `.github/workflows/build-apk.yml`. A ZIP uploaded as a single file to GitHub does NOT get extracted or built.

Open **Actions > Build Android APK > Run workflow**. Once successful, download the `home-depot-shopping-debug-apk` artifact, extract it, and install `app-debug.apk` on Android.

Note: Uploading nested folders from Android GitHub mobile web UI can be difficult. A desktop browser or a git client is usually easier. Do not upload the ZIP directly and expect the build to run.
