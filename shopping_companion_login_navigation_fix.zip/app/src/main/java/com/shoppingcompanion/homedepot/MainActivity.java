package com.shoppingcompanion.homedepot;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView appView, cartView;
    private LinearLayout cartPanel;
    private FrameLayout root;
    private boolean importing = false;
    private boolean inspecting = false;
    private boolean attemptedOnThisPage = false;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        setContentView(root);
        appView = makeView();
        root.addView(appView);
        appView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void openCart() { runOnUiThread(() -> openCartBrowser()); }
        }, "ShoppingBridge");
        appView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url.startsWith("file:///android_asset/")) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }
        });
        appView.loadUrl("file:///android_asset/index.html");
        CookieManager.getInstance().setAcceptCookie(true);
    }
    private WebView makeView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setJavaScriptCanOpenWindowsAutomatically(false);
        w.setWebChromeClient(new WebChromeClient());
        return w;
    }
    private void openCartBrowser() {
        if (cartView != null) return;
        importing = true;
        cartView = makeView();
        CookieManager.getInstance().setAcceptThirdPartyCookies(cartView, true);
        LinearLayout browserPanel = new LinearLayout(this);
        browserPanel.setOrientation(LinearLayout.VERTICAL);
        browserPanel.setBackgroundColor(0xFF182332);
        Button back = new Button(this); back.setText("Close Home Depot");
        Button importButton = new Button(this); importButton.setText("Import Cart Now");
        LinearLayout controls = new LinearLayout(this);
        controls.addView(back, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(importButton, new LinearLayout.LayoutParams(0, -2, 1));
        browserPanel.addView(controls);
        browserPanel.addView(cartView, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(browserPanel);
        cartPanel = browserPanel;
        back.setOnClickListener(v -> closeCart());
        importButton.setOnClickListener(v -> { importing=true; inspectCart(true); });
        cartView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                Uri u = Uri.parse(url);
                String host = u.getHost();
                if (host == null || !(host.equals("homedepot.com") || host.endsWith(".homedepot.com"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch(Exception ignored) {}
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView v, String url) {
                attemptedOnThisPage = false;
                if (importing && (url.contains("/mycart") || url.contains("/cart"))) {
                    v.postDelayed(() -> inspectCart(false), 3000);
                }
            }
        });
        cartView.loadUrl("https://www.homedepot.com/mycart/home");
        Toast.makeText(this, "Sign in if needed. Cart import will be attempted automatically.", Toast.LENGTH_LONG).show();
    }
    private void inspectCart(boolean manual) {
        if (cartView == null || !importing || inspecting || (!manual && attemptedOnThisPage)) return;
        inspecting = true;
        // Extract only rendered cart product rows. No credentials or cookies leave the WebView.
        String script = "(function(){try{const text=document.body.innerText||'';const rows=[...document.querySelectorAll('[data-testid*=cart-item], [data-testid*=CartItem], [class*=cartItem], [class*=CartItem]')];const items=rows.map(r=>{const name=(r.querySelector('[data-testid*=product-title], [class*=productTitle], a[href*=\"/p/\"]')?.innerText||'').trim();const priceText=(r.querySelector('[data-testid*=price], [class*=price]')?.innerText||'');const m=priceText.match(/\\$\\s*([0-9,]+(?:\\.[0-9]{2})?)/);const q=r.querySelector('input[type=number], select, [data-testid*=quantity]');const quantity=parseInt(q?.value||q?.innerText||'1',10);return {name:name,price:m?Number(m[1].replace(/,/g,'')):null,quantity:quantity,url:r.querySelector('a[href*=\"/p/\"]')?.href||''}}).filter(x=>x.name&&Number.isInteger(x.quantity)&&x.quantity>0);return JSON.stringify({items:items,empty:/your cart is empty|shopping cart is empty|no items in your cart/i.test(text),count:rows.length});}catch(e){return JSON.stringify({error:String(e)})}})()";
        cartView.evaluateJavascript(script, result -> {
            try {
                String decoded = new JSONArray("[" + result + "]").getString(0);
                JSONObject obj = new JSONObject(decoded);
                inspecting = false;
                if (obj.optBoolean("empty")) {
                    if (manual) showError("Your Home Depot cart is empty. Your shopping list was not changed.");
                    return;
                }
                JSONArray items = obj.optJSONArray("items");
                if (items != null && items.length()>0 && items.length()==obj.optInt("count")) {
                    importing=false;
                    attemptedOnThisPage = true;
                    new AlertDialog.Builder(this).setTitle("Replace shopping list?")
                        .setMessage("Replace your current shopping list with " + items.length() + " Home Depot cart items?")
                        .setNegativeButton("Cancel", (d,w)->closeCart())
                        .setPositiveButton("Replace", (d,w)->{
                            closeCart();
                            appView.evaluateJavascript("window.importHomeDepotCart(" + JSONObject.quote(items.toString()) + ")", null);
                        }).show();
                } else {
                    if (manual) showRetryDialog("Could not read cart items yet. Sign in, open your cart, and tap Import Cart Now. Your shopping list is unchanged.");
                }
            } catch(Exception e) { inspecting=false; if (manual) showRetryDialog("Could not read the cart. Your shopping list is unchanged."); }
        });
    }
    private void showRetryDialog(String message) {
        if (cartView == null) return;
        importing=false;
        new AlertDialog.Builder(this).setTitle("Cart import not completed").setMessage(message)
            .setPositiveButton("Retry", (d,w)->{ importing=true; inspectCart(true); })
            .setNegativeButton("Cancel", (d,w)->closeCart()).show();
    }
    private void showError(String message) { new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",(d,w)->{}).show(); }
    private void closeCart() { importing=false; inspecting=false; if(cartView!=null){ if(cartPanel!=null)root.removeView(cartPanel);cartView.destroy();cartView=null;cartPanel=null;} }
    @Override public void onBackPressed() {
        if (cartView!=null) { if(cartView.canGoBack())cartView.goBack(); else closeCart(); }
        else if (appView.canGoBack()) appView.goBack(); else super.onBackPressed();
    }
}
